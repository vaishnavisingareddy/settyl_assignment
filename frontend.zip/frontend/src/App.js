
import React, { useEffect, useState } from 'react';


import io from 'socket.io-client';

const socket = io('http://localhost:5000'); 

function App() {
  
  const [content, setContent] = useState('');
  const [documentId, setDocumentId] = useState('');

  useEffect(() => {
    socket.on('document', (data) => {
      setContent(data);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleJoinDocument = () => {
    socket.emit('join', documentId);
  };

  const handleContentChange = (e) => {
    const newContent = e.target.value;
    setContent(newContent);
    socket.emit('update', { documentId, content: newContent });
  };

  return (
    <div className="App">
      <h1>Collaborative Document Editor</h1>
      <input
        type="text"
        placeholder="Enter Document ID"
        value={documentId}
        onChange={(e) => setDocumentId(e.target.value)}
      />
      <br />
      <button onClick={handleJoinDocument}>Join Document</button>
      <br />
      <textarea value={content} onChange={handleContentChange}></textarea>
    </div>
  );
}

export default App;
